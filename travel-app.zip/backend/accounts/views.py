from rest_framework import status, generics, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView
from django.contrib.auth import get_user_model, logout
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import send_mail
from django.conf import settings
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.template.loader import render_to_string
from django.shortcuts import get_object_or_404
from .serializers import (
    UserRegistrationSerializer, UserLoginSerializer, UserProfileSerializer,
    UserPreferencesSerializer, PasswordChangeSerializer,
    PasswordResetRequestSerializer, PasswordResetConfirmSerializer
)
from .models import UserPreferences

User = get_user_model()

class RegisterView(generics.CreateAPIView):
    """User registration view"""
    
    queryset = User.objects.all()
    serializer_class = UserRegistrationSerializer
    permission_classes = [permissions.AllowAny]
    
    def create(self, request, *args, **kwargs):
        """Create new user and return tokens"""
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        
        # Generate JWT tokens
        refresh = RefreshToken.for_user(user)
        
        return Response({
            'user': UserProfileSerializer(user).data,
            'tokens': {
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            },
            'message': 'Registration successful!'
        }, status=status.HTTP_201_CREATED)


class CustomTokenObtainPairView(TokenObtainPairView):
    """Custom login view with user data"""
    
    def post(self, request, *args, **kwargs):
        """Login user and return tokens with user data"""
        serializer = UserLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        
        # Generate JWT tokens
        refresh = RefreshToken.for_user(user)
        
        return Response({
            'user': UserProfileSerializer(user).data,
            'tokens': {
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            },
            'message': 'Login successful!'
        }, status=status.HTTP_200_OK)


class ProfileView(generics.RetrieveUpdateAPIView):
    """User profile view"""
    
    serializer_class = UserProfileSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_object(self):
        """Return current user"""
        return self.request.user
    
    def update(self, request, *args, **kwargs):
        """Update user profile"""
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        
        return Response({
            'user': serializer.data,
            'message': 'Profile updated successfully!'
        })


class UserPreferencesView(generics.RetrieveUpdateAPIView):
    """User preferences view"""
    
    serializer_class = UserPreferencesSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_object(self):
        """Get or create user preferences"""
        preferences, created = UserPreferences.objects.get_or_create(
            user=self.request.user
        )
        return preferences
    
    def update(self, request, *args, **kwargs):
        """Update user preferences"""
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        
        return Response({
            'preferences': serializer.data,
            'message': 'Preferences updated successfully!'
        })


class PasswordChangeView(APIView):
    """Password change view"""
    
    permission_classes = [permissions.IsAuthenticated]
    
    def post(self, request):
        """Change user password"""
        serializer = PasswordChangeSerializer(
            data=request.data,
            context={'request': request}
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        
        return Response({
            'message': 'Password changed successfully!'
        }, status=status.HTTP_200_OK)


class PasswordResetRequestView(APIView):
    """Password reset request view"""
    
    permission_classes = [permissions.AllowAny]
    
    def post(self, request):
        """Send password reset email"""
        serializer = PasswordResetRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        email = serializer.validated_data['email']
        user = User.objects.get(email=email)
        
        # Generate reset token
        token = default_token_generator.make_token(user)
        uid = urlsafe_base64_encode(force_bytes(user.pk))
        
        # Create reset URL (you'll need to implement this in frontend)
        reset_url = f"{settings.FRONTEND_URL}/reset-password/{uid}/{token}/"
        
        # Send email
        subject = 'Password Reset Request'
        message = f"""
        Hi {user.first_name},
        
        You requested a password reset for your Travel App account.
        Click the link below to reset your password:
        
        {reset_url}
        
        If you didn't request this, please ignore this email.
        
        Best regards,
        Travel App Team
        """
        
        try:
            send_mail(
                subject,
                message,
                settings.DEFAULT_FROM_EMAIL,
                [email],
                fail_silently=False,
            )
            return Response({
                'message': 'Password reset email sent successfully!'
            }, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({
                'error': 'Failed to send email. Please try again later.'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PasswordResetConfirmView(APIView):
    """Password reset confirmation view"""
    
    permission_classes = [permissions.AllowAny]
    
    def post(self, request, uid, token):
        """Confirm password reset"""
        try:
            user_id = force_str(urlsafe_base64_decode(uid))
            user = User.objects.get(pk=user_id)
        except (TypeError, ValueError, OverflowError, User.DoesNotExist):
            return Response({
                'error': 'Invalid reset link.'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        if not default_token_generator.check_token(user, token):
            return Response({
                'error': 'Invalid or expired reset link.'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        serializer = PasswordResetConfirmSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        # Reset password
        user.set_password(serializer.validated_data['new_password'])
        user.save()
        
        return Response({
            'message': 'Password reset successfully!'
        }, status=status.HTTP_200_OK)


class LogoutView(APIView):
    """Logout view"""
    
    permission_classes = [permissions.IsAuthenticated]
    
    def post(self, request):
        """Logout user by blacklisting refresh token"""
        try:
            refresh_token = request.data.get('refresh_token')
            if refresh_token:
                token = RefreshToken(refresh_token)
                token.blacklist()
            
            logout(request)
            return Response({
                'message': 'Logged out successfully!'
            }, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({
                'error': 'Invalid token.'
            }, status=status.HTTP_400_BAD_REQUEST)


class UserStatsView(APIView):
    """User statistics view"""
    
    permission_classes = [permissions.IsAuthenticated]
    
    def get(self, request):
        """Get user statistics"""
        user = request.user
        
        # Import here to avoid circular imports
        from travel.models import Review, Wishlist
        from bookings.models import Booking
        
        stats = {
            'total_bookings': Booking.objects.filter(user=user).count(),
            'completed_trips': Booking.objects.filter(
                user=user, 
                status='completed'
            ).count(),
            'total_reviews': Review.objects.filter(user=user).count(),
            'wishlist_items': Wishlist.objects.filter(user=user).aggregate(
                total=models.Sum('destinations__count')
            )['total'] or 0,
            'member_since': user.date_joined,
            'profile_completion': self.calculate_profile_completion(user)
        }
        
        return Response(stats)
    
    def calculate_profile_completion(self, user):
        """Calculate profile completion percentage"""
        fields_to_check = [
            'first_name', 'last_name', 'phone_number', 'date_of_birth',
            'bio', 'country', 'city', 'profile_picture'
        ]
        
        completed_fields = 0
        for field in fields_to_check:
            if getattr(user, field):
                completed_fields += 1
        
        return int((completed_fields / len(fields_to_check)) * 100)


@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def verify_email(request):
    """Verify user email"""
    # This would typically involve sending a verification email
    # For now, we'll just mark the user as verified
    user = request.user
    user.is_verified = True
    user.save()
    
    return Response({
        'message': 'Email verified successfully!'
    }, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def check_username_availability(request):
    """Check if username is available"""
    username = request.GET.get('username')
    if not username:
        return Response({
            'error': 'Username parameter is required.'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    is_available = not User.objects.filter(username=username).exists()
    
    return Response({
        'username': username,
        'is_available': is_available
    })
