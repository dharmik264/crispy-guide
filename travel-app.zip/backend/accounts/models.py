from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core.validators import RegexValidator

class User(AbstractUser):
    """Extended User model with travel-specific fields"""
    
    email = models.EmailField(unique=True)
    phone_regex = RegexValidator(
        regex=r'^\+?1?\d{9,15}$',
        message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed."
    )
    phone_number = models.CharField(validators=[phone_regex], max_length=17, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    profile_picture = models.ImageField(upload_to='profile_pics/', null=True, blank=True)
    bio = models.TextField(max_length=500, blank=True)
    
    # Travel preferences
    preferred_travel_style = models.CharField(
        max_length=20,
        choices=[
            ('budget', 'Budget'),
            ('mid_range', 'Mid Range'),
            ('luxury', 'Luxury'),
            ('backpacker', 'Backpacker'),
            ('family', 'Family'),
            ('business', 'Business'),
        ],
        default='mid_range'
    )
    
    # Location fields
    country = models.CharField(max_length=100, blank=True)
    city = models.CharField(max_length=100, blank=True)
    
    # Account settings
    is_verified = models.BooleanField(default=False)
    newsletter_subscription = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'first_name', 'last_name']
    
    class Meta:
        db_table = 'auth_user'
    
    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.email})"
    
    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}".strip()


class UserPreferences(models.Model):
    """User travel preferences and settings"""
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='preferences')
    
    # Travel preferences
    preferred_destinations = models.JSONField(default=list, blank=True)
    travel_interests = models.JSONField(default=list, blank=True)  # ['adventure', 'culture', 'food', etc.]
    budget_range = models.CharField(
        max_length=20,
        choices=[
            ('0-500', '$0 - $500'),
            ('500-1000', '$500 - $1,000'),
            ('1000-2500', '$1,000 - $2,500'),
            ('2500-5000', '$2,500 - $5,000'),
            ('5000+', '$5,000+'),
        ],
        blank=True
    )
    
    # Notification preferences
    email_notifications = models.BooleanField(default=True)
    sms_notifications = models.BooleanField(default=False)
    push_notifications = models.BooleanField(default=True)
    
    # Privacy settings
    profile_visibility = models.CharField(
        max_length=10,
        choices=[
            ('public', 'Public'),
            ('friends', 'Friends Only'),
            ('private', 'Private'),
        ],
        default='public'
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Preferences for {self.user.full_name}"
