from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth import get_user_model
from .models import UserPreferences

User = get_user_model()

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    """Custom user admin"""
    
    list_display = [
        'email', 'username', 'first_name', 'last_name', 
        'is_verified', 'preferred_travel_style', 'date_joined'
    ]
    list_filter = [
        'is_staff', 'is_superuser', 'is_active', 'is_verified',
        'preferred_travel_style', 'date_joined'
    ]
    search_fields = ['email', 'username', 'first_name', 'last_name']
    ordering = ['-date_joined']
    
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Travel Profile', {
            'fields': (
                'phone_number', 'date_of_birth', 'profile_picture', 'bio',
                'preferred_travel_style', 'country', 'city'
            )
        }),
        ('Account Status', {
            'fields': ('is_verified', 'newsletter_subscription')
        }),
    )
    
    add_fieldsets = BaseUserAdmin.add_fieldsets + (
        ('Personal Info', {
            'fields': ('email', 'first_name', 'last_name')
        }),
    )


@admin.register(UserPreferences)
class UserPreferencesAdmin(admin.ModelAdmin):
    """User preferences admin"""
    
    list_display = [
        'user', 'budget_range', 'email_notifications', 
        'profile_visibility', 'created_at'
    ]
    list_filter = [
        'budget_range', 'email_notifications', 'sms_notifications',
        'push_notifications', 'profile_visibility'
    ]
    search_fields = ['user__email', 'user__first_name', 'user__last_name']
    readonly_fields = ['created_at', 'updated_at']
