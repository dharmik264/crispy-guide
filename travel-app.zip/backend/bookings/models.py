from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MinValueValidator
from decimal import Decimal
import uuid

User = get_user_model()

class Booking(models.Model):
    """Travel bookings"""
    
    BOOKING_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('cancelled', 'Cancelled'),
        ('completed', 'Completed'),
        ('refunded', 'Refunded'),
    ]
    
    BOOKING_TYPE_CHOICES = [
        ('flight', 'Flight'),
        ('hotel', 'Hotel'),
        ('package', 'Travel Package'),
        ('activity', 'Activity'),
        ('transport', 'Transportation'),
    ]
    
    # Basic booking info
    booking_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bookings')
    destination = models.ForeignKey('travel.Destination', on_delete=models.CASCADE, related_name='bookings')
    
    # Booking details
    booking_type = models.CharField(max_length=20, choices=BOOKING_TYPE_CHOICES)
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    
    # Dates and duration
    start_date = models.DateField()
    end_date = models.DateField()
    booking_date = models.DateTimeField(auto_now_add=True)
    
    # Pricing
    base_price = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    taxes = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    fees = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    discount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    total_price = models.DecimalField(max_digits=10, decimal_places=2)
    
    # Travelers
    adults = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    children = models.PositiveIntegerField(default=0)
    infants = models.PositiveIntegerField(default=0)
    
    # Status and confirmation
    status = models.CharField(max_length=20, choices=BOOKING_STATUS_CHOICES, default='pending')
    confirmation_number = models.CharField(max_length=50, blank=True)
    
    # Additional details
    special_requests = models.TextField(blank=True)
    booking_details = models.JSONField(default=dict, blank=True)  # Store additional booking info
    
    # Contact information
    contact_name = models.CharField(max_length=200)
    contact_email = models.EmailField()
    contact_phone = models.CharField(max_length=20)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', '-created_at']),
            models.Index(fields=['status', '-created_at']),
            models.Index(fields=['start_date']),
        ]
    
    def save(self, *args, **kwargs):
        # Calculate total price
        self.total_price = self.base_price + self.taxes + self.fees - self.discount
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"Booking {self.booking_id} - {self.title} by {self.user.full_name}"
    
    @property
    def duration_days(self):
        return (self.end_date - self.start_date).days + 1
    
    @property
    def total_travelers(self):
        return self.adults + self.children + self.infants
    
    @property
    def is_upcoming(self):
        from django.utils import timezone
        return self.start_date > timezone.now().date()
    
    @property
    def is_past(self):
        from django.utils import timezone
        return self.end_date < timezone.now().date()


class Payment(models.Model):
    """Payment records for bookings"""
    
    PAYMENT_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('refunded', 'Refunded'),
        ('partially_refunded', 'Partially Refunded'),
    ]
    
    PAYMENT_METHOD_CHOICES = [
        ('credit_card', 'Credit Card'),
        ('debit_card', 'Debit Card'),
        ('paypal', 'PayPal'),
        ('bank_transfer', 'Bank Transfer'),
        ('crypto', 'Cryptocurrency'),
    ]
    
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name='payments')
    payment_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    
    # Payment details
    amount = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    currency = models.CharField(max_length=3, default='USD')
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES)
    status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='pending')
    
    # External payment info
    external_payment_id = models.CharField(max_length=200, blank=True)
    gateway_response = models.JSONField(default=dict, blank=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    processed_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Payment {self.payment_id} - ${self.amount} ({self.status})"


class Itinerary(models.Model):
    """Travel itineraries"""
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='itineraries')
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    
    # Trip details
    start_date = models.DateField()
    end_date = models.DateField()
    destinations = models.ManyToManyField('travel.Destination', related_name='itineraries')
    
    # Settings
    is_public = models.BooleanField(default=False)
    is_template = models.BooleanField(default=False)
    
    # Metadata
    total_budget = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    traveler_count = models.PositiveIntegerField(default=1)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = 'Itineraries'
    
    def __str__(self):
        return f"{self.title} by {self.user.full_name}"
    
    @property
    def duration_days(self):
        return (self.end_date - self.start_date).days + 1


class ItineraryDay(models.Model):
    """Daily itinerary items"""
    
    itinerary = models.ForeignKey(Itinerary, on_delete=models.CASCADE, related_name='days')
    day_number = models.PositiveIntegerField()
    date = models.DateField()
    title = models.CharField(max_length=200, blank=True)
    notes = models.TextField(blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['day_number']
        unique_together = ['itinerary', 'day_number']
    
    def __str__(self):
        return f"Day {self.day_number} - {self.itinerary.title}"


class ItineraryActivity(models.Model):
    """Activities within itinerary days"""
    
    ACTIVITY_TYPE_CHOICES = [
        ('flight', 'Flight'),
        ('accommodation', 'Accommodation'),
        ('activity', 'Activity'),
        ('meal', 'Meal'),
        ('transport', 'Transportation'),
        ('sightseeing', 'Sightseeing'),
        ('free_time', 'Free Time'),
    ]
    
    day = models.ForeignKey(ItineraryDay, on_delete=models.CASCADE, related_name='activities')
    activity_type = models.CharField(max_length=20, choices=ACTIVITY_TYPE_CHOICES)
    
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    location = models.CharField(max_length=200, blank=True)
    
    # Timing
    start_time = models.TimeField(null=True, blank=True)
    end_time = models.TimeField(null=True, blank=True)
    duration_minutes = models.PositiveIntegerField(null=True, blank=True)
    
    # Pricing
    cost = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    is_booked = models.BooleanField(default=False)
    booking = models.ForeignKey(Booking, on_delete=models.SET_NULL, null=True, blank=True)
    
    # Additional info
    notes = models.TextField(blank=True)
    contact_info = models.JSONField(default=dict, blank=True)
    
    # Order within the day
    order = models.PositiveIntegerField(default=0)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['order', 'start_time']
        verbose_name_plural = 'Itinerary Activities'
    
    def __str__(self):
        return f"{self.title} - {self.day}"
