import logging
import time
import json
import uuid
from datetime import datetime, timedelta
from django.utils.deprecation import MiddlewareMixin
from django.http import JsonResponse, HttpResponse
from django.contrib.auth.models import AnonymousUser
from django.core.cache import cache
from django.conf import settings
from django.utils import timezone
from django.db import connection
from django.contrib.gis.geoip2 import GeoIP2
from django.core.exceptions import ValidationError
import re

# Set up logging
logger = logging.getLogger(__name__)

class RequestLoggingMiddleware(MiddlewareMixin):
    """
    Enhanced middleware to log all API requests and responses with detailed information
    """
    
    def process_request(self, request):
        """Log incoming requests with comprehensive details"""
        request.start_time = time.time()
        request.request_id = str(uuid.uuid4())[:8]  # Short request ID for tracking
        
        # Get client information
        client_ip = self.get_client_ip(request)
        user_agent = request.META.get('HTTP_USER_AGENT', 'Unknown')
        
        # Log request details
        logger.info(f"[{request.request_id}] Request: {request.method} {request.path}")
        logger.info(f"[{request.request_id}] User: {request.user if hasattr(request, 'user') else 'Anonymous'}")
        logger.info(f"[{request.request_id}] IP: {client_ip}")
        logger.info(f"[{request.request_id}] User-Agent: {user_agent}")
        
        # Log query parameters
        if request.GET:
            logger.info(f"[{request.request_id}] Query Params: {dict(request.GET)}")
        
        # Log request body for POST/PUT/PATCH requests
        if request.body and request.content_type == 'application/json':
            try:
                body = json.loads(request.body.decode('utf-8'))
                # Don't log sensitive data
                sensitive_fields = ['password', 'token', 'secret', 'key']
                for field in sensitive_fields:
                    if field in body:
                        body[field] = '***'
                logger.info(f"[{request.request_id}] Request Body: {body}")
            except json.JSONDecodeError:
                logger.info(f"[{request.request_id}] Request Body: Invalid JSON")
        
        # Store request start time for performance tracking
        cache.set(f"request_start_{request.request_id}", time.time(), 300)
    
    def process_response(self, request, response):
        """Log response details with performance metrics"""
        if hasattr(request, 'start_time') and hasattr(request, 'request_id'):
            duration = time.time() - request.start_time
            
            # Log response details
            logger.info(f"[{request.request_id}] Response: {response.status_code} - Duration: {duration:.3f}s")
            
            # Log slow requests (> 2 seconds)
            if duration > 2.0:
                logger.warning(f"[{request.request_id}] SLOW REQUEST: {duration:.3f}s for {request.method} {request.path}")
            
            # Log database queries count
            if hasattr(connection, 'queries'):
                query_count = len(connection.queries)
                if query_count > 10:  # Log if too many queries
                    logger.warning(f"[{request.request_id}] HIGH DB QUERIES: {query_count} queries")
        
        return response
    
    def process_exception(self, request, exception):
        """Log exceptions"""
        if hasattr(request, 'request_id'):
            logger.error(f"[{request.request_id}] Exception: {str(exception)}", exc_info=True)
    
    def get_client_ip(self, request):
        """Get the client's IP address"""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0].strip()
        else:
            ip = request.META.get('REMOTE_ADDR')
        return ip


class TravelAnalyticsMiddleware(MiddlewareMixin):
    """
    Enhanced middleware to track comprehensive travel-related analytics
    """
    
    def process_request(self, request):
        """Track travel-specific metrics and user behavior"""
        # Track API endpoint usage
        if request.path.startswith('/api/'):
            self.track_api_usage(request)
        
        # Track search queries
        if 'search' in request.path and request.method == 'GET':
            self.track_search_query(request)
        
        # Track user location if available
        if not isinstance(request.user, AnonymousUser):
            self.track_user_location(request)
    
    def process_response(self, request, response):
        """Process response for analytics"""
        # Track successful bookings
        if (request.path.startswith('/api/bookings/') and 
            request.method == 'POST' and 
            response.status_code == 201):
            self.track_booking_creation(request, response)
        
        # Track destination views
        if (request.path.startswith('/api/travel/destinations/') and 
            request.method == 'GET' and 
            response.status_code == 200):
            self.track_destination_view(request)
        
        # Track user engagement
        if not isinstance(request.user, AnonymousUser):
            self.track_user_engagement(request, response)
        
        return response
    
    def track_api_usage(self, request):
        """Track API endpoint usage patterns"""
        endpoint = request.path.replace('/api/', '').split('/')[0]
        user_id = request.user.id if not isinstance(request.user, AnonymousUser) else None
        
        # Cache API usage stats
        cache_key = f"api_usage_{endpoint}_{datetime.now().strftime('%Y%m%d%H')}"
        current_count = cache.get(cache_key, 0)
        cache.set(cache_key, current_count + 1, 3600)  # 1 hour cache
        
        logger.info(f"Travel Analytics: API '{endpoint}' accessed by user {user_id}")
    
    def track_search_query(self, request):
        """Track search queries for analytics and recommendations"""
        query = request.GET.get('q', '')
        location = request.GET.get('location', '')
        category = request.GET.get('category', '')
        price_range = request.GET.get('price_range', '')
        
        search_data = {
            'query': query,
            'location': location,
            'category': category,
            'price_range': price_range,
            'timestamp': timezone.now().isoformat(),
            'user_id': request.user.id if not isinstance(request.user, AnonymousUser) else None,
            'ip': self.get_client_ip(request)
        }
        
        # Store search analytics
        cache_key = f"search_analytics_{datetime.now().strftime('%Y%m%d')}"
        searches = cache.get(cache_key, [])
        searches.append(search_data)
        cache.set(cache_key, searches, 86400)  # 24 hours
        
        logger.info(f"Search Analytics: {search_data}")
    
    def track_user_location(self, request):
        """Track user location for personalized recommendations"""
        try:
            client_ip = self.get_client_ip(request)
            if client_ip and client_ip not in ['127.0.0.1', 'localhost']:
                # Use GeoIP2 to get location (requires GeoIP2 database)
                # g = GeoIP2()
                # location = g.city(client_ip)
                # This is a placeholder - implement actual geolocation
                pass
        except Exception as e:
            logger.debug(f"Could not determine user location: {e}")
    
    def track_booking_creation(self, request, response):
        """Track when bookings are created"""
        user_id = request.user.id if not isinstance(request.user, AnonymousUser) else None
        
        # Increment booking counter
        cache_key = f"bookings_today_{datetime.now().strftime('%Y%m%d')}"
        current_count = cache.get(cache_key, 0)
        cache.set(cache_key, current_count + 1, 86400)
        
        logger.info(f"Booking Analytics: New booking created by user {user_id}")
    
    def track_destination_view(self, request):
        """Track destination page views"""
        destination_id = request.path.split('/')[-2] if request.path.endswith('/') else request.path.split('/')[-1]
        
        # Track popular destinations
        cache_key = f"destination_views_{destination_id}"
        current_views = cache.get(cache_key, 0)
        cache.set(cache_key, current_views + 1, 86400)
        
        logger.info(f"Destination Analytics: Destination {destination_id} viewed")
    
    def track_user_engagement(self, request, response):
        """Track user engagement metrics"""
        user_id = request.user.id
        
        # Update last activity
        cache_key = f"user_activity_{user_id}"
        activity_data = {
            'last_seen': timezone.now().isoformat(),
            'last_endpoint': request.path,
            'session_requests': cache.get(f"session_requests_{user_id}", 0) + 1
        }
        cache.set(cache_key, activity_data, 3600)
        cache.set(f"session_requests_{user_id}", activity_data['session_requests'], 3600)
    
    def get_client_ip(self, request):
        """Get the client's IP address"""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0].strip()
        else:
            ip = request.META.get('REMOTE_ADDR')
        return ip


class AdvancedRateLimitMiddleware(MiddlewareMixin):
    """
    Advanced rate limiting middleware with different limits for different endpoints
    """
    
    def __init__(self, get_response):
        self.get_response = get_response
        # Rate limits: {endpoint_pattern: (requests_per_minute, requests_per_hour)}
        self.rate_limits = {
            '/api/auth/login/': (5, 20),  # Stricter for login
            '/api/auth/register/': (3, 10),  # Stricter for registration
            '/api/bookings/': (10, 100),  # Moderate for bookings
            '/api/travel/search/': (30, 300),  # Higher for search
            '/api/': (60, 600),  # Default for other API endpoints
        }
        super().__init__(get_response)
    
    def process_request(self, request):
        """Check rate limits for API requests"""
        if not request.path.startswith('/api/'):
            return None
        
        client_ip = self.get_client_ip(request)
        user_id = request.user.id if not isinstance(request.user, AnonymousUser) else None
        
        # Use user ID if authenticated, otherwise IP
        identifier = f"user_{user_id}" if user_id else f"ip_{client_ip}"
        
        # Find matching rate limit
        rate_limit = self.get_rate_limit(request.path)
        if not rate_limit:
            return None
        
        requests_per_minute, requests_per_hour = rate_limit
        
        # Check minute limit
        minute_key = f"rate_limit_{identifier}_{int(time.time()) // 60}"
        minute_count = cache.get(minute_key, 0)
        
        if minute_count >= requests_per_minute:
            return JsonResponse({
                'error': 'Rate limit exceeded. Too many requests per minute.',
                'retry_after': 60 - (int(time.time()) % 60)
            }, status=429)
        
        # Check hour limit
        hour_key = f"rate_limit_{identifier}_{int(time.time()) // 3600}"
        hour_count = cache.get(hour_key, 0)
        
        if hour_count >= requests_per_hour:
            return JsonResponse({
                'error': 'Rate limit exceeded. Too many requests per hour.',
                'retry_after': 3600 - (int(time.time()) % 3600)
            }, status=429)
        
        # Increment counters
        cache.set(minute_key, minute_count + 1, 60)
        cache.set(hour_key, hour_count + 1, 3600)
        
        return None
    
    def get_rate_limit(self, path):
        """Get rate limit for specific path"""
        for pattern, limit in self.rate_limits.items():
            if path.startswith(pattern):
                return limit
        return None
    
    def get_client_ip(self, request):
        """Get the client's IP address"""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0].strip()
        else:
            ip = request.META.get('REMOTE_ADDR')
        return ip


class SecurityMiddleware(MiddlewareMixin):
    """
    Custom security middleware for travel-specific security measures
    """
    
    def __init__(self, get_response):
        self.get_response = get_response
        # Suspicious patterns to detect
        self.suspicious_patterns = [
            r'<script.*?>.*?</script>',  # XSS attempts
            r'union.*select',  # SQL injection
            r'drop.*table',  # SQL injection
            r'exec\(',  # Code execution
            r'eval\(',  # Code execution
        ]
        super().__init__(get_response)
    
    def process_request(self, request):
        """Check for security threats"""
        # Check for suspicious patterns in request data
        if self.contains_suspicious_content(request):
            logger.warning(f"Suspicious request detected from {self.get_client_ip(request)}: {request.path}")
            return JsonResponse({
                'error': 'Request blocked for security reasons.'
            }, status=403)
        
        # Check for too many failed login attempts
        if request.path == '/api/auth/login/' and request.method == 'POST':
            if self.is_login_blocked(request):
                return JsonResponse({
                    'error': 'Too many failed login attempts. Please try again later.'
                }, status=429)
        
        return None
    
    def process_response(self, request, response):
        """Add security headers"""
        # Add security headers
        response['X-Content-Type-Options'] = 'nosniff'
        response['X-Frame-Options'] = 'DENY'
        response['X-XSS-Protection'] = '1; mode=block'
        response['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        
        # Track failed login attempts
        if (request.path == '/api/auth/login/' and 
            request.method == 'POST' and 
            response.status_code == 400):
            self.track_failed_login(request)
        
        return response
    
    def contains_suspicious_content(self, request):
        """Check if request contains suspicious patterns"""
        # Check query parameters
        for key, value in request.GET.items():
            for pattern in self.suspicious_patterns:
                if re.search(pattern, value, re.IGNORECASE):
                    return True
        
        # Check POST data
        if request.body:
            try:
                body_str = request.body.decode('utf-8')
                for pattern in self.suspicious_patterns:
                    if re.search(pattern, body_str, re.IGNORECASE):
                        return True
            except UnicodeDecodeError:
                pass
        
        return False
    
    def is_login_blocked(self, request):
        """Check if login is blocked due to too many failed attempts"""
        client_ip = self.get_client_ip(request)
        cache_key = f"failed_logins_{client_ip}"
        failed_attempts = cache.get(cache_key, 0)
        
        return failed_attempts >= 5  # Block after 5 failed attempts
    
    def track_failed_login(self, request):
        """Track failed login attempts"""
        client_ip = self.get_client_ip(request)
        cache_key = f"failed_logins_{client_ip}"
        failed_attempts = cache.get(cache_key, 0)
        
        # Increment failed attempts with exponential backoff
        cache.set(cache_key, failed_attempts + 1, 300 * (2 ** min(failed_attempts, 5)))
    
    def get_client_ip(self, request):
        """Get the client's IP address"""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0].strip()
        else:
            ip = request.META.get('REMOTE_ADDR')
        return ip


class PerformanceMonitoringMiddleware(MiddlewareMixin):
    """
    Middleware to monitor application performance and detect issues
    """
    
    def process_request(self, request):
        """Start performance monitoring"""
        request.perf_start = time.time()
        request.db_queries_start = len(connection.queries) if hasattr(connection, 'queries') else 0
    
    def process_response(self, request, response):
        """Monitor performance metrics"""
        if hasattr(request, 'perf_start'):
            duration = time.time() - request.perf_start
            db_queries = len(connection.queries) - request.db_queries_start if hasattr(connection, 'queries') else 0
            
            # Store performance metrics
            perf_data = {
                'path': request.path,
                'method': request.method,
                'duration': duration,
                'db_queries': db_queries,
                'status_code': response.status_code,
                'timestamp': timezone.now().isoformat()
            }
            
            # Cache performance data for analysis
            cache_key = f"performance_{datetime.now().strftime('%Y%m%d%H')}"
            perf_list = cache.get(cache_key, [])
            perf_list.append(perf_data)
            cache.set(cache_key, perf_list, 3600)
            
            # Log performance issues
            if duration > 5.0:  # Very slow requests
                logger.error(f"VERY SLOW REQUEST: {duration:.3f}s for {request.method} {request.path}")
            elif duration > 2.0:  # Slow requests
                logger.warning(f"SLOW REQUEST: {duration:.3f}s for {request.method} {request.path}")
            
            if db_queries > 20:  # Too many database queries
                logger.warning(f"HIGH DB QUERIES: {db_queries} queries for {request.method} {request.path}")
        
        return response


class APIVersioningMiddleware(MiddlewareMixin):
    """
    Middleware to handle API versioning
    """
    
    def process_request(self, request):
        """Handle API versioning"""
        if request.path.startswith('/api/'):
            # Check for version in header
            api_version = request.META.get('HTTP_API_VERSION', '1.0')
            
            # Validate version
            supported_versions = ['1.0', '1.1', '2.0']
            if api_version not in supported_versions:
                return JsonResponse({
                    'error': f'Unsupported API version: {api_version}',
                    'supported_versions': supported_versions
                }, status=400)
            
            # Store version in request for use in views
            request.api_version = api_version
            
            # Log API version usage
            logger.info(f"API v{api_version} accessed: {request.path}")
        
        return None
    
    def process_response(self, request, response):
        """Add version information to response"""
        if request.path.startswith('/api/'):
            response['API-Version'] = getattr(request, 'api_version', '1.0')
        return response


class UserActivityTrackingMiddleware(MiddlewareMixin):
    """
    Middleware to track detailed user activity for analytics and personalization
    """
    
    def process_request(self, request):
        """Track user activity"""
        if not isinstance(request.user, AnonymousUser):
            # Update user's last activity
            cache_key = f"user_last_activity_{request.user.id}"
            activity_data = {
                'timestamp': timezone.now().isoformat(),
                'path': request.path,
                'method': request.method,
                'ip': self.get_client_ip(request),
                'user_agent': request.META.get('HTTP_USER_AGENT', '')[:200]
            }
            cache.set(cache_key, activity_data, 86400)  # 24 hours
            
            # Track page views for personalization
            if request.method == 'GET':
                self.track_page_view(request)
    
    def track_page_view(self, request):
        """Track page views for user personalization"""
        user_id = request.user.id
        page_views_key = f"user_page_views_{user_id}"
        
        # Get existing page views
        page_views = cache.get(page_views_key, {})
        
        # Increment view count for this path
        path = request.path
        page_views[path] = page_views.get(path, 0) + 1
        
        # Store updated page views
        cache.set(page_views_key, page_views, 86400 * 7)  # 7 days
    
    def get_client_ip(self, request):
        """Get the client's IP address"""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0].strip()
        else:
            ip = request.META.get('REMOTE_ADDR')
        return ip
