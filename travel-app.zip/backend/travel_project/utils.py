"""
Utility functions for middleware and other components
"""
from django.core.cache import cache
from django.utils import timezone
from datetime import datetime, timedelta
import json

def get_performance_stats():
    """Get performance statistics from cache"""
    current_hour = datetime.now().strftime('%Y%m%d%H')
    cache_key = f"performance_{current_hour}"
    perf_data = cache.get(cache_key, [])
    
    if not perf_data:
        return {}
    
    # Calculate statistics
    durations = [item['duration'] for item in perf_data]
    db_queries = [item['db_queries'] for item in perf_data]
    
    stats = {
        'total_requests': len(perf_data),
        'avg_duration': sum(durations) / len(durations),
        'max_duration': max(durations),
        'min_duration': min(durations),
        'avg_db_queries': sum(db_queries) / len(db_queries),
        'max_db_queries': max(db_queries),
        'slow_requests': len([d for d in durations if d > 2.0]),
        'very_slow_requests': len([d for d in durations if d > 5.0])
    }
    
    return stats

def get_api_usage_stats():
    """Get API usage statistics"""
    current_hour = datetime.now().strftime('%Y%m%d%H')
    stats = {}
    
    # Common API endpoints
    endpoints = ['travel', 'bookings', 'auth', 'users']
    
    for endpoint in endpoints:
        cache_key = f"api_usage_{endpoint}_{current_hour}"
        count = cache.get(cache_key, 0)
        stats[endpoint] = count
    
    return stats

def get_search_analytics():
    """Get search analytics data"""
    today = datetime.now().strftime('%Y%m%d')
    cache_key = f"search_analytics_{today}"
    searches = cache.get(cache_key, [])
    
    if not searches:
        return {}
    
    # Analyze search data
    total_searches = len(searches)
    unique_queries = len(set(search['query'] for search in searches if search['query']))
    popular_locations = {}
    popular_categories = {}
    
    for search in searches:
        if search['location']:
            popular_locations[search['location']] = popular_locations.get(search['location'], 0) + 1
        if search['category']:
            popular_categories[search['category']] = popular_categories.get(search['category'], 0) + 1
    
    return {
        'total_searches': total_searches,
        'unique_queries': unique_queries,
        'popular_locations': sorted(popular_locations.items(), key=lambda x: x[1], reverse=True)[:10],
        'popular_categories': sorted(popular_categories.items(), key=lambda x: x[1], reverse=True)[:10]
    }

def clear_rate_limit(identifier):
    """Clear rate limit for a specific identifier (for admin use)"""
    current_minute = int(time.time()) // 60
    current_hour = int(time.time()) // 3600
    
    minute_key = f"rate_limit_{identifier}_{current_minute}"
    hour_key = f"rate_limit_{identifier}_{current_hour}"
    
    cache.delete(minute_key)
    cache.delete(hour_key)

def get_user_activity_summary(user_id):
    """Get user activity summary"""
    cache_key = f"user_last_activity_{user_id}"
    activity = cache.get(cache_key)
    
    page_views_key = f"user_page_views_{user_id}"
    page_views = cache.get(page_views_key, {})
    
    session_requests_key = f"session_requests_{user_id}"
    session_requests = cache.get(session_requests_key, 0)
    
    return {
        'last_activity': activity,
        'page_views': page_views,
        'session_requests': session_requests
    }
