from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils.text import slugify

User = get_user_model()

class Category(models.Model):
    """Travel destination categories"""
    
    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(max_length=100, unique=True, blank=True)
    description = models.TextField(blank=True)
    icon = models.CharField(max_length=50, blank=True)  # Font Awesome icon class
    color = models.CharField(max_length=7, default='#007bff')  # Hex color
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name_plural = 'Categories'
        ordering = ['name']
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)
    
    def __str__(self):
        return self.name


class Destination(models.Model):
    """Travel destinations"""
    
    name = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200, unique=True, blank=True)
    description = models.TextField()
    short_description = models.CharField(max_length=300)
    
    # Location details
    country = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    address = models.TextField(blank=True)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    
    # Images
    main_image = models.ImageField(upload_to='destinations/main/', null=True, blank=True)
    gallery_images = models.JSONField(default=list, blank=True)  # List of image URLs
    
    # Categorization
    categories = models.ManyToManyField(Category, related_name='destinations')
    tags = models.JSONField(default=list, blank=True)  # ['beach', 'family-friendly', etc.]
    
    # Pricing and details
    price_range = models.CharField(
        max_length=20,
        choices=[
            ('budget', 'Budget ($)'),
            ('mid_range', 'Mid Range ($$)'),
            ('luxury', 'Luxury ($$$)'),
            ('ultra_luxury', 'Ultra Luxury ($$$$)'),
        ],
        default='mid_range'
    )
    
    # Ratings and popularity
    average_rating = models.DecimalField(max_digits=3, decimal_places=2, default=0.00)
    total_reviews = models.PositiveIntegerField(default=0)
    popularity_score = models.PositiveIntegerField(default=0)
    
    # Availability and status
    is_active = models.BooleanField(default=True)
    is_featured = models.BooleanField(default=False)
    best_time_to_visit = models.CharField(max_length=200, blank=True)
    
    # SEO fields
    meta_title = models.CharField(max_length=200, blank=True)
    meta_description = models.CharField(max_length=300, blank=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-popularity_score', '-average_rating', 'name']
        indexes = [
            models.Index(fields=['country', 'city']),
            models.Index(fields=['is_active', 'is_featured']),
            models.Index(fields=['-popularity_score']),
        ]
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.name}, {self.city}, {self.country}"
    
    @property
    def location(self):
        return f"{self.city}, {self.country}"


class Review(models.Model):
    """User reviews for destinations"""
    
    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name='reviews')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reviews')
    
    # Review content
    title = models.CharField(max_length=200)
    content = models.TextField()
    rating = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)]
    )
    
    # Review details
    visit_date = models.DateField(null=True, blank=True)
    travel_type = models.CharField(
        max_length=20,
        choices=[
            ('solo', 'Solo Travel'),
            ('couple', 'Couple'),
            ('family', 'Family'),
            ('friends', 'Friends'),
            ('business', 'Business'),
        ],
        blank=True
    )
    
    # Images
    images = models.JSONField(default=list, blank=True)  # List of image URLs
    
    # Moderation
    is_approved = models.BooleanField(default=True)
    is_featured = models.BooleanField(default=False)
    
    # Engagement
    helpful_votes = models.PositiveIntegerField(default=0)
    total_votes = models.PositiveIntegerField(default=0)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
        unique_together = ['destination', 'user']  # One review per user per destination
        indexes = [
            models.Index(fields=['destination', '-created_at']),
            models.Index(fields=['user', '-created_at']),
            models.Index(fields=['-rating']),
        ]
    
    def __str__(self):
        return f"Review by {self.user.full_name} for {self.destination.name}"
    
    @property
    def helpfulness_ratio(self):
        if self.total_votes == 0:
            return 0
        return (self.helpful_votes / self.total_votes) * 100


class Wishlist(models.Model):
    """User wishlists for destinations"""
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='wishlists')
    name = models.CharField(max_length=100, default='My Wishlist')
    description = models.TextField(blank=True)
    destinations = models.ManyToManyField(Destination, related_name='wishlisted_by')
    is_public = models.BooleanField(default=False)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
        unique_together = ['user', 'name']
    
    def __str__(self):
        return f"{self.name} by {self.user.full_name}"
    
    @property
    def destination_count(self):
        return self.destinations.count()


class TravelTip(models.Model):
    """Travel tips for destinations"""
    
    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name='tips')
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='travel_tips')
    
    title = models.CharField(max_length=200)
    content = models.TextField()
    tip_type = models.CharField(
        max_length=20,
        choices=[
            ('transport', 'Transportation'),
            ('accommodation', 'Accommodation'),
            ('food', 'Food & Dining'),
            ('activities', 'Activities'),
            ('safety', 'Safety'),
            ('budget', 'Budget'),
            ('culture', 'Culture'),
            ('general', 'General'),
        ],
        default='general'
    )
    
    is_approved = models.BooleanField(default=True)
    upvotes = models.PositiveIntegerField(default=0)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-upvotes', '-created_at']
    
    def __str__(self):
        return f"Tip: {self.title} for {self.destination.name}"
