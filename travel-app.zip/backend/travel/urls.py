from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'destinations', views.DestinationViewSet)
router.register(r'reviews', views.ReviewViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('search/', views.SearchDestinationsView.as_view(), name='search-destinations'),
    path('popular/', views.PopularDestinationsView.as_view(), name='popular-destinations'),
]
