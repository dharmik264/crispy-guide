import { Hero } from "@/components/hero"
import { FeaturedDestinations } from "@/components/featured-destinations"
import { SearchSection } from "@/components/search-section"
import { TravelCategories } from "@/components/travel-categories"
import { Testimonials } from "@/components/testimonials"
import { Newsletter } from "@/components/newsletter"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <SearchSection />
        <FeaturedDestinations />
        <TravelCategories />
        <Testimonials />
        <Newsletter />
      </main>
      <Footer />
    </div>
  )
}
