"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Star, MapPin, Heart, Calendar, Users, Clock, ArrowLeft, Share2 } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { destinationsApi } from "@/lib/api"

interface Destination {
  id: string
  name: string
  city: string
  country: string
  short_description: string
  price_range: string
  average_rating: number
  total_reviews: number
  main_image?: string
  tags: string[]
  is_featured: boolean
}

export default function DestinationDetailPage() {
  const params = useParams()
  const [destination, setDestination] = useState<Destination | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (params.id) {
      loadDestination(params.id as string)
    }
  }, [params.id])

  const loadDestination = async (id: string) => {
    try {
      setLoading(true)
      const response = await destinationsApi.getDestination(id)
      setDestination(response)
    } catch (error) {
      console.error("Error loading destination:", error)
    } finally {
      setLoading(false)
    }
  }

  const getPriceDisplay = (priceRange: string) => {
    const priceMap = {
      budget: "From $199",
      mid_range: "From $449",
      luxury: "From $699",
      ultra_luxury: "From $999",
    }
    return priceMap[priceRange as keyof typeof priceMap] || "Price varies"
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading destination...</p>
        </div>
      </div>
    )
  }

  if (!destination) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Destination not found</h1>
          <Button asChild>
            <Link href="/destinations">Back to Destinations</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="relative h-96 overflow-hidden">
        <Image
          src={destination.main_image || "/placeholder.svg"}
          alt={destination.name}
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute inset-0 flex items-end">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 pb-8">
            <div className="text-white">
              <div className="flex items-center gap-2 mb-4">
                <Button variant="ghost" size="sm" asChild className="text-white hover:bg-white/20">
                  <Link href="/destinations">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Back to Destinations
                  </Link>
                </Button>
              </div>
              <h1 className="font-heading text-4xl sm:text-5xl font-bold mb-2">{destination.name}</h1>
              <div className="flex items-center gap-4 text-white/90">
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-1" />
                  {destination.city}, {destination.country}
                </div>
                <div className="flex items-center">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                  {destination.average_rating} ({destination.total_reviews} reviews)
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-4">About this destination</h2>
              <p className="text-muted-foreground text-lg leading-relaxed">{destination.short_description}</p>
            </div>

            <div className="mb-6">
              <h3 className="text-xl font-semibold mb-3">What makes it special</h3>
              <div className="flex flex-wrap gap-2">
                {destination.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-sm">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>

            <Separator className="my-6" />

            <div className="mb-6">
              <h3 className="text-xl font-semibold mb-4">What to expect</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-3">
                  <Clock className="h-5 w-5 text-primary" />
                  <div>
                    <p className="font-medium">Best time to visit</p>
                    <p className="text-sm text-muted-foreground">Year-round destination</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Users className="h-5 w-5 text-primary" />
                  <div>
                    <p className="font-medium">Perfect for</p>
                    <p className="text-sm text-muted-foreground">Couples, families, solo travelers</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Booking Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-4">
              <CardContent className="p-6">
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl font-bold text-primary">{getPriceDisplay(destination.price_range)}</span>
                    <Button variant="ghost" size="sm">
                      <Heart className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground">per person</p>
                </div>

                <div className="space-y-4 mb-6">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Check-in</label>
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <Calendar className="h-4 w-4 mr-2" />
                      Select date
                    </Button>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Check-out</label>
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <Calendar className="h-4 w-4 mr-2" />
                      Select date
                    </Button>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Guests</label>
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <Users className="h-4 w-4 mr-2" />1 guest
                    </Button>
                  </div>
                </div>

                <Button className="w-full mb-4" size="lg">
                  Book Now
                </Button>

                <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                  <Share2 className="h-4 w-4" />
                  Share this destination
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
