"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Star, MapPin, Heart, Search, Loader2 } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { destinationsApi, categoriesApi } from "@/lib/api"

interface Destination {
  id: string
  name: string
  city: string
  country: string
  short_description: string
  price_range: string
  average_rating: number
  total_reviews: number
  main_image?: string
  tags: string[]
  is_featured: boolean
}

export default function DestinationsPage() {
  const [destinations, setDestinations] = useState<Destination[]>([])
  const [categories, setCategories] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedPriceRange, setSelectedPriceRange] = useState("all")

  useEffect(() => {
    loadDestinations()
    loadCategories()
  }, [])

  useEffect(() => {
    loadDestinations()
  }, [searchQuery, selectedCategory, selectedPriceRange])

  const loadDestinations = async () => {
    try {
      setLoading(true)
      const response = await destinationsApi.getDestinations({
        search: searchQuery || undefined,
        category: selectedCategory === "all" ? undefined : selectedCategory,
        price_range: selectedPriceRange === "all" ? undefined : selectedPriceRange,
      })
      setDestinations(response.results)
    } catch (error) {
      console.error("Error loading destinations:", error)
    } finally {
      setLoading(false)
    }
  }

  const loadCategories = async () => {
    try {
      const response = await categoriesApi.getCategories()
      setCategories(response)
    } catch (error) {
      console.error("Error loading categories:", error)
    }
  }

  const getPriceDisplay = (priceRange: string) => {
    const priceMap = {
      budget: "From $199",
      mid_range: "From $449",
      luxury: "From $699",
      ultra_luxury: "From $999",
    }
    return priceMap[priceRange as keyof typeof priceMap] || "Price varies"
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="font-heading text-4xl sm:text-5xl font-bold mb-4">Explore Destinations</h1>
            <p className="text-xl text-primary-foreground/90 max-w-2xl mx-auto">
              Discover amazing places around the world and plan your next adventure
            </p>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-background border-b">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search destinations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.name.toLowerCase()}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedPriceRange} onValueChange={setSelectedPriceRange}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Price Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Prices</SelectItem>
                <SelectItem value="budget">Budget ($199+)</SelectItem>
                <SelectItem value="mid_range">Mid Range ($449+)</SelectItem>
                <SelectItem value="luxury">Luxury ($699+)</SelectItem>
                <SelectItem value="ultra_luxury">Ultra Luxury ($999+)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            <div className="mb-6">
              <p className="text-muted-foreground">
                {destinations.length} destination{destinations.length !== 1 ? "s" : ""} found
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {destinations.map((destination) => (
                <Card
                  key={destination.id}
                  className="group overflow-hidden hover:shadow-lg transition-all duration-300"
                >
                  <div className="relative overflow-hidden">
                    <Image
                      src={destination.main_image || "/placeholder.svg"}
                      alt={destination.name}
                      width={400}
                      height={300}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <Button
                      size="sm"
                      variant="ghost"
                      className="absolute top-2 right-2 bg-background/80 hover:bg-background"
                    >
                      <Heart className="h-4 w-4" />
                    </Button>
                    <div className="absolute bottom-2 left-2">
                      <Badge variant="secondary" className="bg-background/90">
                        {getPriceDisplay(destination.price_range)}
                      </Badge>
                    </div>
                  </div>

                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-semibold text-card-foreground group-hover:text-primary transition-colors">
                          {destination.name}
                        </h3>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <MapPin className="h-3 w-3 mr-1" />
                          {destination.city}, {destination.country}
                        </div>
                      </div>
                    </div>

                    <p className="text-sm text-muted-foreground mb-3">{destination.short_description}</p>

                    <div className="flex flex-wrap gap-1 mb-3">
                      {destination.tags.slice(0, 3).map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium ml-1">{destination.average_rating}</span>
                        <span className="text-sm text-muted-foreground ml-1">({destination.total_reviews})</span>
                      </div>
                      <Button size="sm" asChild>
                        <Link href={`/destinations/${destination.id}`}>View Details</Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  )
}
