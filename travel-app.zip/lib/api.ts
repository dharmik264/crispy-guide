// API configuration and base functions
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api"

const IS_PREVIEW_MODE =
  typeof window !== "undefined" &&
  (window.location.hostname.includes("v0.app") ||
    (window.location.hostname.includes("localhost") && !process.env.NEXT_PUBLIC_API_URL))

interface ApiResponse<T> {
  data?: T
  error?: string
  message?: string
}

class ApiError extends Error {
  status: number

  constructor(message: string, status: number) {
    super(message)
    this.status = status
    this.name = "ApiError"
  }
}

const MOCK_DESTINATIONS = [
  {
    id: "1",
    name: "Santorini",
    city: "Santorini",
    country: "Greece",
    short_description: "Iconic white-washed buildings and breathtaking sunsets over the Aegean Sea",
    price_range: "luxury",
    average_rating: 4.9,
    total_reviews: 1247,
    main_image: "/santorini-sunset-white-buildings.png",
    tags: ["Romantic", "Sunset Views", "Wine"],
    is_featured: true,
  },
  {
    id: "2",
    name: "Machu Picchu",
    city: "Cusco",
    country: "Peru",
    short_description: "Ancient Incan citadel high in the Andes Mountains",
    price_range: "mid_range",
    average_rating: 4.8,
    total_reviews: 892,
    main_image: "/machu-picchu-ancient-ruins.png",
    tags: ["Adventure", "History", "Hiking"],
    is_featured: true,
  },
  {
    id: "3",
    name: "Tokyo",
    city: "Tokyo",
    country: "Japan",
    short_description: "Dynamic city mixing tradition with modern innovation",
    price_range: "luxury",
    average_rating: 4.7,
    total_reviews: 2156,
    main_image: "/placeholder-t1lem.png",
    tags: ["Culture", "Food", "Technology"],
    is_featured: true,
  },
  {
    id: "4",
    name: "Bali",
    city: "Denpasar",
    country: "Indonesia",
    short_description: "Tropical paradise with beaches, temples, and rich culture",
    price_range: "budget",
    average_rating: 4.6,
    total_reviews: 1834,
    main_image: "/placeholder-vhhem.png",
    tags: ["Beach", "Temples", "Yoga"],
    is_featured: true,
  },
  {
    id: "5",
    name: "Paris",
    city: "Paris",
    country: "France",
    short_description: "City of Light with iconic landmarks and romantic atmosphere",
    price_range: "luxury",
    average_rating: 4.5,
    total_reviews: 3421,
    main_image: "/paris-eiffel-tower-romantic-city.png",
    tags: ["Romance", "Art", "History"],
    is_featured: true,
  },
  {
    id: "6",
    name: "Dubai",
    city: "Dubai",
    country: "UAE",
    short_description: "Futuristic city with luxury shopping and modern architecture",
    price_range: "ultra_luxury",
    average_rating: 4.4,
    total_reviews: 1567,
    main_image: "/dubai-burj-khalifa-skyline.png",
    tags: ["Luxury", "Shopping", "Modern"],
    is_featured: true,
  },
]

const MOCK_CATEGORIES = [
  { id: "1", name: "Adventure", description: "Thrilling outdoor experiences", icon: "mountain" },
  { id: "2", name: "Beach", description: "Tropical paradise destinations", icon: "sun" },
  { id: "3", name: "Culture", description: "Rich cultural experiences", icon: "museum" },
  { id: "4", name: "Romance", description: "Perfect for couples", icon: "heart" },
  { id: "5", name: "Food", description: "Culinary adventures", icon: "utensils" },
  { id: "6", name: "History", description: "Historical landmarks", icon: "landmark" },
]

// Get auth token from localStorage
const getAuthToken = (): string | null => {
  if (typeof window === "undefined") return null
  return localStorage.getItem("access_token")
}

// Set auth token in localStorage
const setAuthToken = (token: string): void => {
  if (typeof window !== "undefined") {
    localStorage.setItem("access_token", token)
  }
}

// Remove auth token from localStorage
const removeAuthToken = (): void => {
  if (typeof window !== "undefined") {
    localStorage.removeItem("access_token")
    localStorage.removeItem("refresh_token")
  }
}

// Base fetch function with error handling
async function apiFetch<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const url = `${API_BASE_URL}${endpoint}`
  const token = getAuthToken()

  const config: RequestInit = {
    headers: {
      "Content-Type": "application/json",
      "API-Version": "1.0",
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    },
    ...options,
  }

  try {
    const response = await fetch(url, config)

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw new ApiError(errorData.error || errorData.message || `HTTP ${response.status}`, response.status)
    }

    const data = await response.json()
    return data
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError("Network error occurred", 0)
  }
}

const simulateDelay = (ms = 500) => new Promise((resolve) => setTimeout(resolve, ms))

// Auth API functions
export const authApi = {
  async login(email: string, password: string) {
    if (IS_PREVIEW_MODE) {
      await simulateDelay()
      const mockUser = {
        id: "1",
        username: "demo_user",
        email: email,
        first_name: "Demo",
        last_name: "User",
        profile: {
          phone_number: "+1234567890",
          country: "United States",
          city: "New York",
        },
      }
      const mockTokens = {
        access: "mock_access_token",
        refresh: "mock_refresh_token",
      }

      setAuthToken(mockTokens.access)
      localStorage.setItem("refresh_token", mockTokens.refresh)

      return {
        user: mockUser,
        tokens: mockTokens,
        message: "Login successful",
      }
    }

    const response = await apiFetch<{
      user: any
      tokens: { access: string; refresh: string }
      message: string
    }>("/auth/login/", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    })

    // Store tokens
    if (response.tokens) {
      setAuthToken(response.tokens.access)
      localStorage.setItem("refresh_token", response.tokens.refresh)
    }

    return response
  },

  async register(userData: {
    username: string
    email: string
    password: string
    password_confirm: string
    first_name: string
    last_name: string
    phone_number?: string
    country?: string
    city?: string
  }) {
    if (IS_PREVIEW_MODE) {
      await simulateDelay()
      const mockUser = {
        id: "1",
        username: userData.username,
        email: userData.email,
        first_name: userData.first_name,
        last_name: userData.last_name,
        profile: {
          phone_number: userData.phone_number || "",
          country: userData.country || "",
          city: userData.city || "",
        },
      }
      const mockTokens = {
        access: "mock_access_token",
        refresh: "mock_refresh_token",
      }

      setAuthToken(mockTokens.access)
      localStorage.setItem("refresh_token", mockTokens.refresh)

      return {
        user: mockUser,
        tokens: mockTokens,
        message: "Registration successful",
      }
    }

    const response = await apiFetch<{
      user: any
      tokens: { access: string; refresh: string }
      message: string
    }>("/auth/register/", {
      method: "POST",
      body: JSON.stringify(userData),
    })

    // Store tokens
    if (response.tokens) {
      setAuthToken(response.tokens.access)
      localStorage.setItem("refresh_token", response.tokens.refresh)
    }

    return response
  },

  async logout() {
    if (IS_PREVIEW_MODE) {
      await simulateDelay(200)
      removeAuthToken()
      return
    }

    const refreshToken = localStorage.getItem("refresh_token")

    try {
      await apiFetch("/auth/logout/", {
        method: "POST",
        body: JSON.stringify({ refresh_token: refreshToken }),
      })
    } catch (error) {
      console.error("Logout error:", error)
    } finally {
      removeAuthToken()
    }
  },

  async getProfile() {
    if (IS_PREVIEW_MODE) {
      await simulateDelay()
      return {
        id: "1",
        username: "demo_user",
        email: "demo@example.com",
        first_name: "Demo",
        last_name: "User",
        profile: {
          phone_number: "+1234567890",
          country: "United States",
          city: "New York",
          bio: "Travel enthusiast exploring the world",
          avatar: "/diverse-user-avatars.png",
        },
      }
    }

    return apiFetch<any>("/auth/profile/")
  },

  async updateProfile(profileData: any) {
    if (IS_PREVIEW_MODE) {
      await simulateDelay()
      return { ...profileData, message: "Profile updated successfully" }
    }

    return apiFetch<any>("/auth/profile/", {
      method: "PATCH",
      body: JSON.stringify(profileData),
    })
  },

  async refreshToken() {
    if (IS_PREVIEW_MODE) {
      await simulateDelay()
      const newToken = "mock_refreshed_token"
      setAuthToken(newToken)
      return { access: newToken }
    }

    const refreshToken = localStorage.getItem("refresh_token")
    if (!refreshToken) throw new ApiError("No refresh token", 401)

    const response = await apiFetch<{ access: string }>("/auth/token/refresh/", {
      method: "POST",
      body: JSON.stringify({ refresh: refreshToken }),
    })

    setAuthToken(response.access)
    return response
  },
}

// Destinations API functions
export const destinationsApi = {
  async getDestinations(params?: {
    page?: number
    search?: string
    category?: string
    price_range?: string
    location?: string
  }) {
    if (IS_PREVIEW_MODE) {
      await simulateDelay()
      let filteredDestinations = [...MOCK_DESTINATIONS]

      if (params?.search) {
        const searchLower = params.search.toLowerCase()
        filteredDestinations = filteredDestinations.filter(
          (dest) =>
            dest.name.toLowerCase().includes(searchLower) ||
            dest.city.toLowerCase().includes(searchLower) ||
            dest.country.toLowerCase().includes(searchLower) ||
            dest.short_description.toLowerCase().includes(searchLower),
        )
      }

      if (params?.category) {
        filteredDestinations = filteredDestinations.filter((dest) =>
          dest.tags.some((tag) => tag.toLowerCase().includes(params.category!.toLowerCase())),
        )
      }

      if (params?.price_range) {
        filteredDestinations = filteredDestinations.filter((dest) => dest.price_range === params.price_range)
      }

      return {
        results: filteredDestinations,
        count: filteredDestinations.length,
        next: null,
        previous: null,
      }
    }

    const queryParams = new URLSearchParams()
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value) queryParams.append(key, value.toString())
      })
    }

    const endpoint = `/travel/destinations/${queryParams.toString() ? `?${queryParams}` : ""}`
    return apiFetch<{
      results: any[]
      count: number
      next: string | null
      previous: string | null
    }>(endpoint)
  },

  async getDestination(id: string) {
    if (IS_PREVIEW_MODE) {
      await simulateDelay()
      const destination = MOCK_DESTINATIONS.find((dest) => dest.id === id)
      if (!destination) {
        throw new ApiError("Destination not found", 404)
      }
      return destination
    }

    return apiFetch<any>(`/travel/destinations/${id}/`)
  },

  async getPopularDestinations() {
    if (IS_PREVIEW_MODE) {
      await simulateDelay()
      return MOCK_DESTINATIONS.filter((dest) => dest.is_featured).slice(0, 4)
    }

    return apiFetch<any[]>("/travel/popular/")
  },

  async searchDestinations(query: string, filters?: any) {
    if (IS_PREVIEW_MODE) {
      await simulateDelay()
      const searchLower = query.toLowerCase()
      const results = MOCK_DESTINATIONS.filter(
        (dest) =>
          dest.name.toLowerCase().includes(searchLower) ||
          dest.city.toLowerCase().includes(searchLower) ||
          dest.country.toLowerCase().includes(searchLower) ||
          dest.short_description.toLowerCase().includes(searchLower) ||
          dest.tags.some((tag) => tag.toLowerCase().includes(searchLower)),
      )

      return {
        results,
        count: results.length,
      }
    }

    const params = new URLSearchParams({ q: query })
    if (filters) {
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value.toString())
      })
    }

    return apiFetch<{
      results: any[]
      count: number
    }>(`/travel/search/?${params}`)
  },
}

// Categories API functions
export const categoriesApi = {
  async getCategories() {
    if (IS_PREVIEW_MODE) {
      await simulateDelay()
      return MOCK_CATEGORIES
    }

    return apiFetch<any[]>("/travel/categories/")
  },
}

// Reviews API functions
export const reviewsApi = {
  async getReviews(destinationId: string, page = 1) {
    return apiFetch<{
      results: any[]
      count: number
      next: string | null
      previous: string | null
    }>(`/travel/reviews/?destination=${destinationId}&page=${page}`)
  },

  async createReview(reviewData: {
    destination: string
    title: string
    content: string
    rating: number
    visit_date?: string
    travel_type?: string
  }) {
    return apiFetch<any>("/travel/reviews/", {
      method: "POST",
      body: JSON.stringify(reviewData),
    })
  },

  async updateReview(id: string, reviewData: any) {
    return apiFetch<any>(`/travel/reviews/${id}/`, {
      method: "PATCH",
      body: JSON.stringify(reviewData),
    })
  },

  async deleteReview(id: string) {
    return apiFetch<any>(`/travel/reviews/${id}/`, {
      method: "DELETE",
    })
  },
}

// Bookings API functions
export const bookingsApi = {
  async getBookings(params?: { status?: string; page?: number }) {
    const queryParams = new URLSearchParams()
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value) queryParams.append(key, value.toString())
      })
    }

    const endpoint = `/bookings/bookings/${queryParams.toString() ? `?${queryParams}` : ""}`
    return apiFetch<{
      results: any[]
      count: number
      next: string | null
      previous: string | null
    }>(endpoint)
  },

  async getBooking(id: string) {
    return apiFetch<any>(`/bookings/bookings/${id}/`)
  },

  async createBooking(bookingData: {
    destination: string
    booking_type: string
    title: string
    description?: string
    start_date: string
    end_date: string
    base_price: number
    adults: number
    children?: number
    infants?: number
    contact_name: string
    contact_email: string
    contact_phone: string
    special_requests?: string
  }) {
    return apiFetch<any>("/bookings/bookings/", {
      method: "POST",
      body: JSON.stringify(bookingData),
    })
  },

  async updateBooking(id: string, bookingData: any) {
    return apiFetch<any>(`/bookings/bookings/${id}/`, {
      method: "PATCH",
      body: JSON.stringify(bookingData),
    })
  },

  async cancelBooking(id: string) {
    return apiFetch<any>(`/bookings/bookings/${id}/`, {
      method: "PATCH",
      body: JSON.stringify({ status: "cancelled" }),
    })
  },

  async getUserBookings() {
    return apiFetch<any[]>("/bookings/my-bookings/")
  },

  async getBookingStats() {
    return apiFetch<any>("/bookings/booking-stats/")
  },
}

// Wishlist API functions
export const wishlistApi = {
  async getWishlists() {
    return apiFetch<any[]>("/travel/wishlists/")
  },

  async createWishlist(name: string, description?: string) {
    return apiFetch<any>("/travel/wishlists/", {
      method: "POST",
      body: JSON.stringify({ name, description }),
    })
  },

  async addToWishlist(wishlistId: string, destinationId: string) {
    return apiFetch<any>(`/travel/wishlists/${wishlistId}/add-destination/`, {
      method: "POST",
      body: JSON.stringify({ destination_id: destinationId }),
    })
  },

  async removeFromWishlist(wishlistId: string, destinationId: string) {
    return apiFetch<any>(`/travel/wishlists/${wishlistId}/remove-destination/`, {
      method: "POST",
      body: JSON.stringify({ destination_id: destinationId }),
    })
  },
}

export { ApiError, getAuthToken, setAuthToken, removeAuthToken }
