#!/usr/bin/env python
"""
Script to create initial Django migrations
"""
import os
import sys
import django

# Add the backend directory to Python path
sys.path.append('/backend')

# Set up Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'travel_project.settings')
django.setup()

from django.core.management import execute_from_command_line

def create_migrations():
    """Create initial migrations for all apps"""
    
    print("Creating migrations for all apps...")
    
    # Create migrations for each app
    apps = ['accounts', 'travel', 'bookings']
    
    for app in apps:
        print(f"\nCreating migrations for {app}...")
        execute_from_command_line(['manage.py', 'makemigrations', app])
    
    print("\nApplying migrations...")
    execute_from_command_line(['manage.py', 'migrate'])
    
    print("\nMigrations completed successfully!")

if __name__ == '__main__':
    create_migrations()
