#!/usr/bin/env python
"""
Script to seed initial data for the travel application
"""
import os
import sys
import django
from decimal import Decimal

# Add the backend directory to Python path
sys.path.append('/backend')

# Set up Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'travel_project.settings')
django.setup()

from django.contrib.auth import get_user_model
from travel.models import Category, Destination
from django.utils.text import slugify

User = get_user_model()

def create_categories():
    """Create initial travel categories"""
    categories_data = [
        {
            'name': 'Beach & Islands',
            'description': 'Beautiful beaches and tropical islands',
            'icon': 'fas fa-umbrella-beach',
            'color': '#00bcd4'
        },
        {
            'name': 'Mountains & Nature',
            'description': 'Mountain ranges, national parks, and natural wonders',
            'icon': 'fas fa-mountain',
            'color': '#4caf50'
        },
        {
            'name': 'Cities & Culture',
            'description': 'Urban destinations rich in culture and history',
            'icon': 'fas fa-city',
            'color': '#ff9800'
        },
        {
            'name': 'Adventure & Sports',
            'description': 'Thrilling adventures and outdoor activities',
            'icon': 'fas fa-hiking',
            'color': '#f44336'
        },
        {
            'name': 'Food & Wine',
            'description': 'Culinary destinations and wine regions',
            'icon': 'fas fa-utensils',
            'color': '#9c27b0'
        },
        {
            'name': 'Historical Sites',
            'description': 'Ancient ruins, monuments, and historical landmarks',
            'icon': 'fas fa-landmark',
            'color': '#795548'
        }
    ]
    
    for cat_data in categories_data:
        category, created = Category.objects.get_or_create(
            name=cat_data['name'],
            defaults={
                'description': cat_data['description'],
                'icon': cat_data['icon'],
                'color': cat_data['color'],
                'slug': slugify(cat_data['name'])
            }
        )
        if created:
            print(f"Created category: {category.name}")

def create_sample_destinations():
    """Create sample destinations"""
    destinations_data = [
        {
            'name': 'Santorini',
            'country': 'Greece',
            'city': 'Santorini',
            'description': 'A stunning Greek island known for its white-washed buildings, blue domes, and breathtaking sunsets over the Aegean Sea.',
            'short_description': 'Iconic Greek island with stunning sunsets and white-washed architecture.',
            'price_range': 'luxury',
            'categories': ['Beach & Islands', 'Cities & Culture'],
            'tags': ['romantic', 'photography', 'sunset', 'wine'],
            'latitude': Decimal('36.3932'),
            'longitude': Decimal('25.4615'),
            'best_time_to_visit': 'April to October'
        },
        {
            'name': 'Machu Picchu',
            'country': 'Peru',
            'city': 'Cusco',
            'description': 'An ancient Incan citadel set high in the Andes Mountains, offering incredible views and rich historical significance.',
            'short_description': 'Ancient Incan citadel high in the Andes Mountains.',
            'price_range': 'mid_range',
            'categories': ['Mountains & Nature', 'Historical Sites', 'Adventure & Sports'],
            'tags': ['hiking', 'history', 'unesco', 'adventure'],
            'latitude': Decimal('-13.1631'),
            'longitude': Decimal('-72.5450'),
            'best_time_to_visit': 'May to September'
        },
        {
            'name': 'Tokyo',
            'country': 'Japan',
            'city': 'Tokyo',
            'description': 'A vibrant metropolis blending traditional culture with cutting-edge technology, famous for its food, shopping, and unique experiences.',
            'short_description': 'Dynamic city mixing tradition with modern innovation.',
            'price_range': 'luxury',
            'categories': ['Cities & Culture', 'Food & Wine'],
            'tags': ['technology', 'food', 'culture', 'shopping'],
            'latitude': Decimal('35.6762'),
            'longitude': Decimal('139.6503'),
            'best_time_to_visit': 'March to May, September to November'
        },
        {
            'name': 'Bali',
            'country': 'Indonesia',
            'city': 'Denpasar',
            'description': 'A tropical paradise known for its beautiful beaches, lush rice terraces, ancient temples, and vibrant culture.',
            'short_description': 'Tropical paradise with beaches, temples, and rich culture.',
            'price_range': 'budget',
            'categories': ['Beach & Islands', 'Cities & Culture', 'Adventure & Sports'],
            'tags': ['beaches', 'temples', 'surfing', 'yoga'],
            'latitude': Decimal('-8.3405'),
            'longitude': Decimal('115.0920'),
            'best_time_to_visit': 'April to October'
        },
        {
            'name': 'Swiss Alps',
            'country': 'Switzerland',
            'city': 'Interlaken',
            'description': 'Majestic mountain range offering world-class skiing, hiking, and some of the most beautiful alpine scenery in the world.',
            'short_description': 'Majestic mountains with world-class skiing and hiking.',
            'price_range': 'ultra_luxury',
            'categories': ['Mountains & Nature', 'Adventure & Sports'],
            'tags': ['skiing', 'hiking', 'mountains', 'luxury'],
            'latitude': Decimal('46.6863'),
            'longitude': Decimal('7.8632'),
            'best_time_to_visit': 'December to March (skiing), June to September (hiking)'
        }
    ]
    
    for dest_data in destinations_data:
        destination, created = Destination.objects.get_or_create(
            name=dest_data['name'],
            country=dest_data['country'],
            defaults={
                'city': dest_data['city'],
                'description': dest_data['description'],
                'short_description': dest_data['short_description'],
                'price_range': dest_data['price_range'],
                'tags': dest_data['tags'],
                'latitude': dest_data['latitude'],
                'longitude': dest_data['longitude'],
                'best_time_to_visit': dest_data['best_time_to_visit'],
                'slug': slugify(dest_data['name']),
                'is_featured': True,
                'popularity_score': 100,
                'average_rating': Decimal('4.5')
            }
        )
        
        if created:
            # Add categories
            for cat_name in dest_data['categories']:
                try:
                    category = Category.objects.get(name=cat_name)
                    destination.categories.add(category)
                except Category.DoesNotExist:
                    pass
            
            print(f"Created destination: {destination.name}")

def create_admin_user():
    """Create admin user"""
    if not User.objects.filter(email='admin@travel.com').exists():
        admin_user = User.objects.create_superuser(
            username='admin',
            email='admin@travel.com',
            password='admin123',
            first_name='Admin',
            last_name='User'
        )
        print(f"Created admin user: {admin_user.email}")

def seed_data():
    """Main function to seed all initial data"""
    print("Starting data seeding...")
    
    create_admin_user()
    create_categories()
    create_sample_destinations()
    
    print("\nData seeding completed successfully!")

if __name__ == '__main__':
    seed_data()
