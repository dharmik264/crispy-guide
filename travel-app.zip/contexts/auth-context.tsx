"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { authApi, ApiError } from "@/lib/api"

interface User {
  id: string
  username: string
  email: string
  first_name: string
  last_name: string
  full_name: string
  profile_picture?: string
  is_verified: boolean
  preferred_travel_style: string
  country?: string
  city?: string
}

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (userData: any) => Promise<void>
  logout: () => Promise<void>
  updateProfile: (profileData: any) => Promise<void>
  isAuthenticated: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  const isAuthenticated = !!user

  // Load user profile on mount
  useEffect(() => {
    loadUser()
  }, [])

  const loadUser = async () => {
    try {
      const token = localStorage.getItem("access_token")
      if (!token) {
        setLoading(false)
        return
      }

      const profile = await authApi.getProfile()
      setUser(profile.user || profile)
    } catch (error) {
      console.error("Failed to load user:", error)
      // Clear invalid token
      localStorage.removeItem("access_token")
      localStorage.removeItem("refresh_token")
    } finally {
      setLoading(false)
    }
  }

  const login = async (email: string, password: string) => {
    try {
      const response = await authApi.login(email, password)
      setUser(response.user)
    } catch (error) {
      if (error instanceof ApiError) {
        throw new Error(error.message)
      }
      throw new Error("Login failed. Please try again.")
    }
  }

  const register = async (userData: any) => {
    try {
      const response = await authApi.register(userData)
      setUser(response.user)
    } catch (error) {
      if (error instanceof ApiError) {
        throw new Error(error.message)
      }
      throw new Error("Registration failed. Please try again.")
    }
  }

  const logout = async () => {
    try {
      await authApi.logout()
    } catch (error) {
      console.error("Logout error:", error)
    } finally {
      setUser(null)
    }
  }

  const updateProfile = async (profileData: any) => {
    try {
      const response = await authApi.updateProfile(profileData)
      setUser(response.user || response)
    } catch (error) {
      if (error instanceof ApiError) {
        throw new Error(error.message)
      }
      throw new Error("Profile update failed. Please try again.")
    }
  }

  const value: AuthContextType = {
    user,
    loading,
    login,
    register,
    logout,
    updateProfile,
    isAuthenticated,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
