"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, Heart, Loader2 } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { destinationsApi } from "@/lib/api"

interface Destination {
  id: string
  name: string
  city: string
  country: string
  short_description: string
  price_range: string
  average_rating: number
  total_reviews: number
  main_image?: string
  tags: string[]
  is_featured: boolean
}

export function FeaturedDestinations() {
  const [destinations, setDestinations] = useState<Destination[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    loadFeaturedDestinations()
  }, [])

  const loadFeaturedDestinations = async () => {
    try {
      setLoading(true)
      setError("") // Clear any previous errors
      console.log("[v0] Loading featured destinations...")
      const response = await destinationsApi.getPopularDestinations()
      console.log("[v0] Destinations loaded successfully:", response.length)
      setDestinations(response.slice(0, 4)) // Show only first 4
    } catch (err) {
      console.error("[v0] Error loading destinations:", err)
      setError("Failed to load destinations")
    } finally {
      setLoading(false)
    }
  }

  const getPriceDisplay = (priceRange: string) => {
    const priceMap = {
      budget: "From $199",
      mid_range: "From $449",
      luxury: "From $699",
      ultra_luxury: "From $999",
    }
    return priceMap[priceRange as keyof typeof priceMap] || "Price varies"
  }

  if (loading) {
    return (
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-foreground mb-4">Featured Destinations</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Discover our handpicked selection of the world's most incredible destinations
            </p>
          </div>
          <div className="flex justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-foreground mb-4">Featured Destinations</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover our handpicked selection of the world's most incredible destinations
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {destinations.map((destination) => (
            <Card
              key={destination.id}
              className="group overflow-hidden hover:shadow-lg transition-all duration-300 border-border bg-card"
            >
              <div className="relative overflow-hidden">
                <Image
                  src={destination.main_image || "/placeholder.svg"}
                  alt={destination.name}
                  width={400}
                  height={300}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <Button
                  size="sm"
                  variant="ghost"
                  className="absolute top-2 right-2 bg-background/80 hover:bg-background"
                >
                  <Heart className="h-4 w-4" />
                </Button>
                <div className="absolute bottom-2 left-2">
                  <Badge variant="secondary" className="bg-background/90">
                    {getPriceDisplay(destination.price_range)}
                  </Badge>
                </div>
              </div>

              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="font-semibold text-card-foreground group-hover:text-primary transition-colors">
                      {destination.name}
                    </h3>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <MapPin className="h-3 w-3 mr-1" />
                      {destination.city}, {destination.country}
                    </div>
                  </div>
                </div>

                <p className="text-sm text-muted-foreground mb-3">{destination.short_description}</p>

                <div className="flex flex-wrap gap-1 mb-3">
                  {destination.tags.slice(0, 3).map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium ml-1">{destination.average_rating}</span>
                    <span className="text-sm text-muted-foreground ml-1">({destination.total_reviews})</span>
                  </div>
                  <Button size="sm" asChild>
                    <Link href={`/destinations/${destination.id}`}>View Details</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" variant="outline" asChild>
            <Link href="/destinations">View All Destinations</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
