"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Waves, Mountain, Building2, Zap, UtensilsCrossed, Landmark } from "lucide-react"
import Link from "next/link"

const categories = [
  {
    id: "beach",
    name: "Beach & Islands",
    description: "Beautiful beaches and tropical islands",
    icon: Waves,
    color: "text-blue-500",
    bgColor: "bg-blue-50 dark:bg-blue-950/20",
    count: "245 destinations",
  },
  {
    id: "mountain",
    name: "Mountains & Nature",
    description: "Mountain ranges and natural wonders",
    icon: Mountain,
    color: "text-green-500",
    bgColor: "bg-green-50 dark:bg-green-950/20",
    count: "189 destinations",
  },
  {
    id: "city",
    name: "Cities & Culture",
    description: "Urban destinations rich in culture",
    icon: Building2,
    color: "text-purple-500",
    bgColor: "bg-purple-50 dark:bg-purple-950/20",
    count: "312 destinations",
  },
  {
    id: "adventure",
    name: "Adventure & Sports",
    description: "Thrilling adventures and activities",
    icon: Zap,
    color: "text-orange-500",
    bgColor: "bg-orange-50 dark:bg-orange-950/20",
    count: "156 destinations",
  },
  {
    id: "food",
    name: "Food & Wine",
    description: "Culinary destinations and wine regions",
    icon: UtensilsCrossed,
    color: "text-red-500",
    bgColor: "bg-red-50 dark:bg-red-950/20",
    count: "98 destinations",
  },
  {
    id: "history",
    name: "Historical Sites",
    description: "Ancient ruins and historical landmarks",
    icon: Landmark,
    color: "text-amber-500",
    bgColor: "bg-amber-50 dark:bg-amber-950/20",
    count: "134 destinations",
  },
]

export function TravelCategories() {
  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-foreground mb-4">Explore by Category</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Find your perfect adventure based on your interests and travel style
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category) => {
            const IconComponent = category.icon
            return (
              <Card
                key={category.id}
                className="group hover:shadow-lg transition-all duration-300 border-border bg-card"
              >
                <CardContent className="p-6">
                  <div className={`w-12 h-12 rounded-lg ${category.bgColor} flex items-center justify-center mb-4`}>
                    <IconComponent className={`h-6 w-6 ${category.color}`} />
                  </div>

                  <h3 className="font-semibold text-lg text-card-foreground mb-2 group-hover:text-primary transition-colors">
                    {category.name}
                  </h3>

                  <p className="text-muted-foreground mb-3">{category.description}</p>

                  <p className="text-sm text-muted-foreground mb-4">{category.count}</p>

                  <Button variant="outline" size="sm" asChild className="w-full bg-transparent">
                    <Link href={`/destinations?category=${category.id}`}>Explore {category.name}</Link>
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
