"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Search, Filter, MapPin, Calendar, Users, DollarSign } from "lucide-react"

export function SearchSection() {
  const [searchFilters, setSearchFilters] = useState({
    destination: "",
    checkIn: "",
    checkOut: "",
    guests: "",
    budget: "",
    category: "",
  })

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-foreground mb-4">Find Your Perfect Trip</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Use our advanced search to discover destinations that match your preferences
          </p>
        </div>

        <Card className="max-w-6xl mx-auto border-border bg-card">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-6">
              {/* Destination */}
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Where to go?"
                  className="pl-10"
                  value={searchFilters.destination}
                  onChange={(e) => setSearchFilters({ ...searchFilters, destination: e.target.value })}
                />
              </div>

              {/* Check-in */}
              <div className="relative">
                <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  type="date"
                  placeholder="Check-in"
                  className="pl-10"
                  value={searchFilters.checkIn}
                  onChange={(e) => setSearchFilters({ ...searchFilters, checkIn: e.target.value })}
                />
              </div>

              {/* Check-out */}
              <div className="relative">
                <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  type="date"
                  placeholder="Check-out"
                  className="pl-10"
                  value={searchFilters.checkOut}
                  onChange={(e) => setSearchFilters({ ...searchFilters, checkOut: e.target.value })}
                />
              </div>

              {/* Guests */}
              <Select
                value={searchFilters.guests}
                onValueChange={(value) => setSearchFilters({ ...searchFilters, guests: value })}
              >
                <SelectTrigger>
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                    <SelectValue placeholder="Guests" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 Guest</SelectItem>
                  <SelectItem value="2">2 Guests</SelectItem>
                  <SelectItem value="3">3 Guests</SelectItem>
                  <SelectItem value="4">4 Guests</SelectItem>
                  <SelectItem value="5+">5+ Guests</SelectItem>
                </SelectContent>
              </Select>

              {/* Budget */}
              <Select
                value={searchFilters.budget}
                onValueChange={(value) => setSearchFilters({ ...searchFilters, budget: value })}
              >
                <SelectTrigger>
                  <div className="flex items-center">
                    <DollarSign className="h-4 w-4 mr-2 text-muted-foreground" />
                    <SelectValue placeholder="Budget" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="budget">Budget ($0-500)</SelectItem>
                  <SelectItem value="mid">Mid-range ($500-1500)</SelectItem>
                  <SelectItem value="luxury">Luxury ($1500+)</SelectItem>
                </SelectContent>
              </Select>

              {/* Category */}
              <Select
                value={searchFilters.category}
                onValueChange={(value) => setSearchFilters({ ...searchFilters, category: value })}
              >
                <SelectTrigger>
                  <div className="flex items-center">
                    <Filter className="h-4 w-4 mr-2 text-muted-foreground" />
                    <SelectValue placeholder="Category" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="beach">Beach & Islands</SelectItem>
                  <SelectItem value="mountain">Mountains & Nature</SelectItem>
                  <SelectItem value="city">Cities & Culture</SelectItem>
                  <SelectItem value="adventure">Adventure & Sports</SelectItem>
                  <SelectItem value="food">Food & Wine</SelectItem>
                  <SelectItem value="history">Historical Sites</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button size="lg" className="w-full">
              <Search className="h-4 w-4 mr-2" />
              Search Destinations
            </Button>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
